---
name: Fry Day Haute Fast-Food
colors:
  surface: '#fff8f7'
  surface-dim: '#f3d3cf'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0ee'
  surface-container: '#ffe9e6'
  surface-container-high: '#ffe2de'
  surface-container-highest: '#fcdbd7'
  on-surface: '#281715'
  on-surface-variant: '#5c403c'
  inverse-surface: '#3f2b29'
  inverse-on-surface: '#ffedea'
  outline: '#916f6b'
  outline-variant: '#e6bdb8'
  surface-tint: '#be0913'
  primary: '#9b000a'
  on-primary: '#ffffff'
  primary-container: '#c51217'
  on-primary-container: '#ffd6d1'
  inverse-primary: '#ffb4ab'
  secondary: '#a63930'
  on-secondary: '#ffffff'
  secondary-container: '#ff7b6e'
  on-secondary-container: '#731310'
  tertiary: '#004b8e'
  on-tertiary: '#ffffff'
  tertiary-container: '#0063b8'
  on-tertiary-container: '#d0e0ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#930009'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#86211b'
  tertiary-fixed: '#d5e3ff'
  tertiary-fixed-dim: '#a6c8ff'
  on-tertiary-fixed: '#001c3b'
  on-tertiary-fixed-variant: '#004787'
  background: '#fff8f7'
  on-background: '#281715'
  surface-variant: '#fcdbd7'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a refined culinary experience for a premier fast-food destination in Faisalabad, Pakistan. It departs sharply from generic, loud, mass-market fast-food tropes in favor of an artisanal "slow-crafted fast food" ethos: premium ingredients, gourmet craftsmanship, and generous hospitality.

The visual style blends **Contemporary Hospitality Minimalism** with **Tactile Warmth**:
- **Atmospheric Depth:** Rich, bold crimson tones counterbalanced by sophisticated neutral surfaces create a dining-room intimacy on digital interfaces.
- **Appetizing Restraint:** Visual space allows high-resolution food photography, crispy textures, and rich sauces to command focus without decorative clutter.
- **Polished Precision:** Clean typographic hierarchy paired with micro-details invokes the feel of embossed menu boards, bespoke packaging, and upscale casual dining.
- **Emotional Intent:** Evokes indulgence, culinary passion, pride, and effortless everyday luxury.

## Colors

The palette establishes an appetizing, rich dining atmosphere anchored in bold culinary reds and warm neutrals:

- **Primary (`#C51217` - Haute Crimson):** The commanding identity color. Represents appetite, culinary passion, and bold flavor signatures. Used for dominant headings, top navigation anchors, primary buttons, and high-impact structural containers.
- **Secondary (`#C75146` - Roasted Terracotta):** A warm, earthy counterweight. Employed for promotional tags, selected chip backgrounds, soft badge backdrops, subtle card accents, and secondary actions.
- **Tertiary (`#0063B8` - Vibrant Cobalt):** A striking accent tone providing energetic contrast. Reserved strictly for focal interactions: special combo callouts, rating stars, price highlights, and active ordering status milestones.
- **Neutral (`#8B716E` - Warm Taupe):** The foundational canvas. Replaces sterile cool white with a grounded, tactile warmth.
- **On-Neutral / Text (`#2B1614` - Deep Espresso):** A rich, dark tone that delivers high-contrast readability without synthetic severity.

### Interaction & Semantic Roles
- **Surface Level 0 (Canvas):** `#fcf8f7`
- **Surface Level 1 (Cards & Modals):** `#ffffff` to cleanly lift food photography from the background canvas.
- **Success / Freshness:** `#1b5e20`
- **Alert / Dietary Warnings:** `#c51217`

## Typography

The type system balances the modern, geometric friendliness of **Outfit** for headings with the readable, human-centric geometry of **Plus Jakarta Sans** for body and interface mechanics.

- **Display & Headlines (Outfit):** Features open letterforms, crisp geometries, and high architectural clarity. It carries authority without aggression, signaling sophistication and premium craft.
- **Interface & Text (Plus Jakarta Sans):** Selected for its natural, welcoming curves and exceptional legibility across dense ingredient listings, nutritional details, prices, and multi-step checkout orders.

## Layout & Spacing

The layout philosophy implements a **Fluid-Responsive 12-Column Grid** engineered for high-appetite visual browsing, smooth mobile takeout ordering, and desktop banquet reservations.

### Grid & Breakpoints
- **Desktop (1200px+):** 12-column layout, max-width `1280px` centered canvas, `margin: 3rem`, `gutter: 1.5rem`.
- **Tablet (768px – 1199px):** 8-column layout, fluid edges, `margin-tablet: 2rem`, `gutter: 1.5rem`.
- **Mobile (< 768px):** 4-column layout, `margin-mobile: 1.25rem`, `gutter-mobile: 1rem`.

### Spacing Rhythm
- **Component Padding:** Built upon a standard 8-point base step (`0.5rem`, `1rem`, `1.5rem`).
- **Section Distancing:** Major meal sections are paced with generous breathing room using `space-xl` (40px) or double increments to prevent meal fatigue.

## Elevation & Depth

Visual hierarchy uses a refined hybrid of **Tonal Layering** and **Sunlit Ambient Shadows**, avoiding harsh computer-generated drops in favor of soft, natural ambient daylight:

1. **Base Surface:** Flat, un-elevated foundational layer.
2. **Surface Tier 1 (Menu Cards, Sticky Navigation, Bottom Sheet Sheets):**
   - Background: Pure White (`#FFFFFF`).
   - Shadow: Soft ambient diffusion with warm crimson undertones.
3. **Surface Tier 2 (Interactive Floating Elements, Floating Cart Pill, Modals):**
   - Background: `#FFFFFF` or Haute Crimson (`#C51217` for primary bars).

## Shapes

The design system embraces a **Pill-shaped (Level 3)** shape language, conveying extreme friendliness, modern warmth, and organic geometries:

- **Base Radius:** Applied to form inputs, small tags, and list-item highlights.
- **Large Radius:** Standard for product menu cards, side carts, and checkout bottom sheets.
- **Full Pill (`rounded-full` / 9999px):** Applied generously to primary action buttons, filter chips, floating order counters, and category pills, inviting instant tactile touch.

## Components

### 1. Buttons
- **Primary Button:** Pill-shaped (`rounded-full`), `#C51217` background, `#FFFFFF` label text, `typography: label-lg`. High-touch padding: `14px 28px`.
- **Secondary Button:** Warm surface with prominent borders and text in `#C51217`.
- **Tertiary Accent CTA:** Pill-shaped, `#0063B8` background for urgent "Order Now" or "Claim Combo" promotions.

### 2. Food & Menu Cards
- Crisp white canvas (`#FFFFFF`) built with rounded pill-like container corners.
- Bottom right corner features an active quick-add circular button (`40px x 40px`, `#C51217` background with white `+` icon).

### 3. Filter Chips & Diet Tags
- **Dietary Badges:** Compact pills with `label-sm` font.
- **Menu Filter Pills:** Active state shifts dynamically to solid `#C51217` with white text.

### 4. Floating Cart & Order Tracker
- Floating bottom pill on mobile devices pinned `16px` above the viewport base.
- Haute Crimson `#C51217` pill housing item count badge, checkout CTA text, and dynamic price total.