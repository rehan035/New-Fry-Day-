---
name: Haute Epicure
colors:
  surface: '#f7faf4'
  surface-dim: '#d8dbd5'
  surface-bright: '#f7faf4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f5ee'
  surface-container: '#ecefe8'
  surface-container-high: '#e6e9e3'
  surface-container-highest: '#e0e3dd'
  on-surface: '#191d19'
  on-surface-variant: '#414846'
  inverse-surface: '#2d312d'
  inverse-on-surface: '#eff2eb'
  outline: '#717975'
  outline-variant: '#c0c8c4'
  surface-tint: '#3f665b'
  primary: '#00251d'
  on-primary: '#ffffff'
  primary-container: '#123b32'
  on-primary-container: '#7da599'
  inverse-primary: '#a5cfc2'
  secondary: '#496553'
  on-secondary: '#ffffff'
  secondary-container: '#c8e7d1'
  on-secondary-container: '#4d6957'
  tertiary: '#2c1c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#473000'
  on-tertiary-container: '#c79432'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecde'
  primary-fixed-dim: '#a5cfc2'
  on-primary-fixed: '#00201a'
  on-primary-fixed-variant: '#264e44'
  secondary-fixed: '#cbead4'
  secondary-fixed-dim: '#afceb8'
  on-secondary-fixed: '#052013'
  on-secondary-fixed-variant: '#314d3c'
  tertiary-fixed: '#ffdeaa'
  tertiary-fixed-dim: '#f5bd58'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5f4100'
  background: '#f7faf4'
  on-background: '#191d19'
  surface-variant: '#e0e3dd'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: 4rem
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Outfit
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Outfit
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Outfit
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-lg:
    fontFamily: Outfit
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-md:
    fontFamily: Outfit
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Outfit
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Outfit
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.04em
  label-md:
    fontFamily: Outfit
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Outfit
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a refined intersection between gourmet culinary craft and contemporary casual dining culture. Designed specifically for an elevated dining brand in Faisalabad, it balances prestigious hospitality with fast-casual energy. 

The aesthetic is clean modern minimalism merged with subtle tactile warmth. The interface relies on generous spatial margins, restrained typographic drama, and crisp photographic hero moments rather than heavy ornamentation. High contrast between deep heritage tones and luminous ivory foundations cultivates an appetizing, distinguished culinary presence. The emotional resonance is calm, indulgent, and effortlessly prestigious.

## Colors

The palette establishes an appetizing, architectural tension between organic culinary freshness and culinary heritage:

- **Primary (`#123B32` - Deep Forest Green):** Anchors brand authority, primary interactive CTA targets, header accents, and structural brand moments.
- **Secondary (`#B9D8C2` - Fresh Mint):** Soft botanical wash applied to subtle callouts, badge backgrounds, selected states, and refreshing accents.
- **Tertiary (`#D9A441` - Muted Gold):** Used sparingly for prestige indicators, chef's specials, promotional ribbons, rating highlights, and micro-delights.
- **Neutral (`#242824` - Soft Charcoal):** Serves as crisp typographical text and high-contrast iconography, avoiding pure artificial black.
- **Canvas Base (`#FAF8F2` - Warm Ivory):** Replaces clinical bright whites to provide an artisanal, linen-like culinary canvas across surfaces, modals, and card backdrops.

Surfaces scale gently from pure Warm Ivory (`#FAF8F2`) into faintly shaded containers (`#F3EFE6`) for cards and nested modules to preserve spatial hierarchy without introducing heavy grey cast.

## Typography

Outfit drives the identity with geometric precision, spacious circular letterforms, and an open, contemporary cadence. 

- Large display and headline titles carry subtle negative tracking (`-0.02em` to `-0.03em`) to impart an editorial, architectural punch.
- Labels, dietary tags, and price points leverage medium and semibold weights with slight positive letter spacing (`0.04em` to `0.08em`) for quick legibility in fast-order contexts.
- Body copy prioritizes generous line-heights on the warm canvas to maintain a relaxed, premium reading experience across menus, ingredient provenance descriptions, and stories.

## Layout & Spacing

The layout is grounded in a responsive 12-column fluid grid system on desktop that scales gracefully down to 8 columns on tablet and 4 columns on mobile. 

Generous negative space is vital: sections breathe with wide canvas margins to reinforce a relaxed, uncluttered haute culinary mood. Elements inside menu cards rely on systematic internal vertical intervals (`space-sm` for secondary micro-copy, `space-md` between meta items, and `space-lg` to divide primary ordering sections). Desktop viewports constrain central catalog grids to a maximum width of `1280px` to maintain optimal scanning efficiency.

## Elevation & Depth

Visual hierarchy rejects harsh, generic drop shadows in favor of ambient culinary warmth and layered tones:

- **Base Layer:** Natural Warm Ivory (`#FAF8F2`) canvas.
- **Contained Surface:** Subtle tint steps (`#F3EFE6`) for elevated menu containers, sticky ordering bars, and navigation rails.
- **Ambient Culinary Cast:** Floating items like the order tray drawer, active cart previews, and dialogs utilize an extra-diffused, warm shadow tinted with the primary neutral: `0 16px 36px -8px rgba(36, 40, 36, 0.08), 0 4px 12px -2px rgba(36, 40, 36, 0.04)`.
- **Micro-Borders:** Crisp, razor-thin outlines using `#123B32` at `8%` to `12%` opacity define card perimeters cleanly on light surfaces without creating visual heaviness.

## Shapes

The design system incorporates smooth, organic curvature that mirrors high-end architectural dining spaces and refined plating:

- Standard components (cards, text fields, menu item enclosures) leverage `0.5rem` (`8px`) border radius.
- Larger interactive panels, culinary story cards, and modals step up to `rounded-lg` (`1rem` / `16px`) and `rounded-xl` (`1.5rem` / `24px`).
- Filter badges, dietary pills, and interactive add-buttons employ full-radius pill styling to echo soft tactile ergonomics and fast touch targets.

## Components

### Buttons
- **Primary Action (e.g., "Add to Bag", "Proceed to Checkout"):** Solid Deep Forest Green background (`#123B32`), Warm Ivory text (`#FAF8F2`), smooth `0.5rem` radius or pill curvature. Subtle scale hover (`scale(1.01)`) with gold focus ring (`#D9A441`).
- **Secondary Action:** Outlined with a 1.5px Deep Forest Green border, transparent background, Deep Forest Green text.
- **Tertiary / Specialty:** Muted Gold background (`#D9A441`) paired with Deep Forest Green text for celebratory, seasonal, or chef's signature callouts.

### Chips & Dietary Pills
- Compact components used for dietary tags (e.g., "Artisanal", "Spicy", "Chef's Pick").
- Fresh Mint background (`#B9D8C2`) at `25%` opacity with Deep Forest Green typography and icons. Active/selected state shifts to solid Fresh Mint with soft charcoal text.

### Menu & Product Cards
- Warm Ivory or `#F3EFE6` surface with subtle `1px` translucent green border (`rgba(18, 59, 50, 0.08)`).
- Edge-to-edge photography at the top with a soft `0.5rem` top corner radius.
- Generous padding (`space-lg`) around the dish title, ingredient list, and pricing.
- Add-to-cart trigger embedded seamlessly as a floating pill button in the bottom right corner.

### Form Inputs & Selectors
- Background: Pure Warm Ivory with a soft `1px` border (`rgba(36, 40, 36, 0.15)`).
- Typography: Soft Charcoal for user inputs, muted olive-charcoal for placeholders.
- Focus State: Border shifts to Deep Forest Green (`#123B32`) with a subtle `3px` Fresh Mint glow (`rgba(185, 216, 194, 0.45)`).

### Checkboxes & Radio Buttons
- Custom circular and rounded-square controls using Deep Forest Green fills when checked, accented by Warm Ivory checks.
- Idle borders sit in a muted charcoal-green outline with smooth ease-in transitions.

### Additional Culinary Components
- **Floating Order Dock:** A high-contrast sticky pill or bottom bar on mobile featuring item counts, total price, and quick checkout in Deep Forest Green with Muted Gold numeral highlights.
- **Chef's Accent Ribbon:** A micro-badge pinned to specialty recipe cards using Muted Gold background and Deep Forest Green uppercase text.